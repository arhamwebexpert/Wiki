# h1
## h2
### h3
#### h3
#### h4
##### h5
###### h6
**Bold**, *Italic*, ~~Strikethrough~~, ***Bold and italic***
paragraphs
## single line code block
``` single line code ```
## multiple line code block
~~~ 
code with begining with ~~~
~~~
SeText h1
===========
SeText h2
===========
horizontal line

------------------
Link Text
[Bootstrap (version: 4.5)](https://getbootstrap.com/)
Image
![example-image](example-image.jpg "An exemplary image")

`inline code`
Web links: https://courses.edx.org/courses/course-v1:HarvardX+CS50W+Web/course/
<p> 
<img src="https://user-images.githubusercontent.com/55930906/84531715-fbfc6600-acb2-11ea-8a17-911be2c38297.png?raw=true"  width =450 height =450 alt= "Login">
</p>
# ordered list:
1. A
2. B
# nested ordered list:
1. A
2. B
3. ``` single line code block ```
   1. ```
      multiple line code block
      ```
      1. ```
            another multiple line code block
        ```
# un ordered list:
* A
* B
# nested un ordered list:
* A
  * B
    * C
      * D