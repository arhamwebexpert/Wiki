SeText h1
===========
SeText h2
===========

# heading  h1
## h2
### h3
#### h3
#### h4
##### h5
###### h6

# attach image

<p> 
  
  <img src="https://user-images.githubusercontent.com/55930906/84531715-fbfc6600-acb2-11ea-8a17-911be2c38297.png?raw=true"  width =450 height =450 alt= "Login">
  
  <img src="https://user-images.githubusercontent.com/55930906/84535544-feae8980-acb9-11ea-81e3-a508bcdd6e33.png?raw=true"  width =450 height =450 alt= "Search">
        
 </p>     
      
# stylings, links and paragraphs
---------------------------

bold - **'bold line'** 
italic  - *italic*
strikethrough - ~~strike~~
bold and italic - ***Bold and italic***
`inline code`
[Bootstrap (version: 4.5)](https://getbootstrap.com/)

paragraph with styling *bold* *italic*,~~strike~~, `inline code`,and ***Bold and italic***.  
simple paragraph 


# Lists 
---------------------------
1. ordered list
2. A
4. links https://www.google.com/
   * nested unordered list
       * Example:
            * ul list
            
              ```
              {
                code block
              }
              ```
              
            * ul list
              ``` single line code block ```


# code block
``` 
    multiple line code block
```
        
 ### list:
 --------------------
**example 1**
* UL list 
  * nested ul
    * B

**example 2**    
1. ol
  * **bold**
  * *italic*
  * ***bold and italic***
  * ~~strike~~



**example 3**
1. OL 1
   * ul 1
   * ul 2
     * ul 2.1

2. OL 2
   * ul 1
     * ul 1.1
   * ul 2
     * ul 2.1